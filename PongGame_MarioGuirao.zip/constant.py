# Constants.py
MARGES_ESCENARI = 50
AMPLA_ESCENARI = 600
ALCADA_ESCENARI = 500
COLOR_FONS = (0, 0, 0)  # Negro
COLOR_JUGADOR1 = (255, 0, 0)  # Rojo para el jugador 1
COLOR_JUGADOR2 = (0, 0, 255)  # Azul para el jugador 2